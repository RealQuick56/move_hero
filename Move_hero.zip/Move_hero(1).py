import pygame
import os
import sys


mapt = input()
lst = os.listdir('maps')
if mapt in lst:
    pygame.init()
    pygame.display.set_caption('Pygame_project')
    with open(f'maps/{mapt}', 'r') as mapFile:
        Level_map = [list(line.strip()) for line in mapFile]
    Cell_size = 60
    size = width, height = round(len(Level_map) * Cell_size * 1.5), round(len(Level_map[0]) * Cell_size * 1.5)
    screen = pygame.display.set_mode(size)
    background = pygame.image.load('img/mario_start.jpg')

    LEFT = width // 8
    TOP = height // 8
    coords_for_players = []
    walls_tile = []
    grass_tile = []

    for x in range(len(Level_map)):
        for y in range(len(Level_map[x])):
            if Level_map[x][y] == '#':
                walls_tile.append((x, y))
            elif Level_map[x][y] == '@':
                coords_for_players.append((x, y))
                grass_tile.append((x, y))
            else:
                grass_tile.append((x, y))


    class Player(pygame.sprite.Sprite):
        def __init__(self, filename):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.image.load(
                filename)
            self.image.set_colorkey('white')
            self.mask = pygame.mask.from_surface(self.image)
            for coords in coords_for_players:
                Level_map[coords[0]][coords[1]] = '.'
                self.rect = self.image.get_rect(
                    topleft=((coords[0] * Cell_size + 15) + LEFT, (coords[1] * Cell_size) + TOP + 5))
                break
            del coords_for_players[0]

        def move_down(self):
            x = (self.rect.left - LEFT) // Cell_size
            y = (self.rect.top - TOP) // Cell_size
            if self.rect.top == (len(Level_map[x]) - 1) * Cell_size + TOP and Level_map[x][0] != '#':
                self.rect[1] = TOP
            elif self.rect.top == (len(Level_map[x]) - 1) * Cell_size + TOP and Level_map[x][0] == '#':
                pass
            else:
                if Level_map[x][y + 1] == '#':
                    pass
                else:
                    self.rect[1] += 60

        def move_up(self):
            x = (self.rect.left - LEFT) // Cell_size
            y = (self.rect.top - TOP) // Cell_size
            if self.rect.top == TOP and Level_map[x][len(Level_map[x]) - 1] != '#':
                self.rect[1] = (len(Level_map[x]) - 1) * Cell_size + TOP
            elif self.rect.top == TOP and Level_map[x][len(Level_map[x]) - 1] == '#':
                pass
            else:
                if Level_map[x][y - 1] == '#':
                    pass
                else:
                    self.rect[1] -= 60

        def move_right(self):
            x = (self.rect.left - LEFT) // Cell_size
            y = (self.rect.top - TOP) // Cell_size
            if self.rect.left == (len(Level_map) - 1) * Cell_size + LEFT and Level_map[0][y] != '#':
                self.rect[0] = LEFT
            elif self.rect.left == (len(Level_map) - 1) * Cell_size + LEFT and Level_map[0][y] == '#':
                pass
            else:
                if Level_map[x + 1][y] == '#':
                    pass
                else:
                    self.rect[0] += 60

        def move_left(self):
            x = (self.rect.left - LEFT) // Cell_size
            y = (self.rect.top - TOP) // Cell_size
            if self.rect.left == LEFT and Level_map[len(Level_map) - 1][y] != '#':
                self.rect[0] = (len(Level_map) - 1) * Cell_size + LEFT
            elif self.rect.left == LEFT and Level_map[len(Level_map) - 1][y] == '#':
                pass
            else:
                if Level_map[x - 1][y] == '#':
                    pass
                else:
                    self.rect[0] -= 60


    class Tile(pygame.sprite.Sprite):
        def __init__(self, filename):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.image.load(
                filename)
            self.image.set_colorkey('white')
            self.mask = pygame.mask.from_surface(self.image)
            for coords in walls_tile:
                self.rect = self.image.get_rect(topleft=((coords[0] * 60) + LEFT, (coords[1] * 60) + TOP))
                break
            del walls_tile[0]


    class Grass(pygame.sprite.Sprite):
        def __init__(self, filename):
            pygame.sprite.Sprite.__init__(self)
            self.image = pygame.image.load(
                filename)
            self.image.set_colorkey('white')
            self.mask = pygame.mask.from_surface(self.image)
            for coords in grass_tile:
                self.rect = self.image.get_rect(topleft=((coords[0] * 60) + LEFT, (coords[1] * 60) + TOP))
                break
            del grass_tile[0]


    player_1 = Player('img/mario.png')
    tiles = pygame.sprite.Group()
    for _ in range(len(walls_tile)):
        tiles.add(Tile('img/box.png'))
    grass = pygame.sprite.Group()
    for _ in range(len(grass_tile)):
        grass.add(Grass('img/grass.png'))

    running = True
    clock = pygame.time.Clock()
    fps = 30
    apple = True
    while running:
        clock.tick(fps)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    player_1.move_down()
                if event.key == pygame.K_w:
                    player_1.move_up()
                if event.key == pygame.K_d:
                    player_1.move_right()
                if event.key == pygame.K_a:
                    player_1.move_left()
            pygame.display.flip()
            screen.blit(background, (0, 0))
            for i in grass:
                screen.blit(i.image, i.rect)
            for i in tiles:
                screen.blit(i.image, i.rect)
            screen.blit(player_1.image, player_1.rect)
    pygame.quit()
else:
    print('НЕВЕРНО ВЕДЕНО НАЗВАНИЕ КАРТЫ')
    sys.exit()